const pool = require('./db');

/**
 * Test de vérification : L'API renvoie-t-elle bien les 5 décimales pour FLEX ?
 */

async function testFlexPrecision() {
  try {
    console.log('\n🧪 TEST: Vérification précision FLEX EMPRUNTEUR (5 décimales)\n');
    
    // Test 1: Récupérer quelques tarifs FLEX avec le cast ::TEXT
    console.log('📊 Test 1: Récupération avec ::TEXT (méthode API)');
    const result1 = await pool.query(`
      SELECT id, produit_id, age, duree_contrat, categorie,
             prime::TEXT as prime, 
             periodicite
      FROM tarif_produit 
      WHERE produit_id = (SELECT id FROM produit WHERE libelle = 'CORIS FLEX EMPRUNTEUR' LIMIT 1)
        AND categorie IN ('amortissable', 'decouvert')
      ORDER BY age, duree_contrat
      LIMIT 10
    `);
    
    console.log('\nRésultats (10 premiers tarifs):');
    result1.rows.forEach(row => {
      const decimals = row.prime.includes('.') ? row.prime.split('.')[1].length : 0;
      const status = decimals >= 5 ? '✅' : '⚠️ ';
      console.log(`${status} Age ${row.age} | ${row.duree_contrat}m | ${row.categorie.padEnd(15)} | Prime: ${row.prime.padEnd(12)} (${decimals} décimales)`);
    });
    
    // Test 2: Statistiques sur la précision
    console.log('\n📊 Test 2: Statistiques de précision');
    const result2 = await pool.query(`
      SELECT 
        categorie,
        COUNT(*) as total,
        COUNT(CASE WHEN prime::TEXT LIKE '%._____%' THEN 1 END) as with_5_decimals,
        MIN(prime::TEXT) as min_prime,
        MAX(prime::TEXT) as max_prime
      FROM tarif_produit 
      WHERE produit_id = (SELECT id FROM produit WHERE libelle = 'CORIS FLEX EMPRUNTEUR' LIMIT 1)
      GROUP BY categorie
      ORDER BY categorie
    `);
    
    console.log('\nStatistiques par catégorie:');
    result2.rows.forEach(row => {
      const percentage = ((row.with_5_decimals / row.total) * 100).toFixed(1);
      console.log(`\n  ${row.categorie}:`);
      console.log(`    - Total: ${row.total} tarifs`);
      console.log(`    - Avec ≥5 décimales: ${row.with_5_decimals} (${percentage}%)`);
      console.log(`    - Prime min: ${row.min_prime}`);
      console.log(`    - Prime max: ${row.max_prime}`);
    });
    
    // Test 3: Vérifier un tarif spécifique (simulation réelle)
    console.log('\n📊 Test 3: Simulation réelle - Age 34, 60 mois, Amortissable');
    const result3 = await pool.query(`
      SELECT prime::TEXT as prime
      FROM tarif_produit 
      WHERE produit_id = (SELECT id FROM produit WHERE libelle = 'CORIS FLEX EMPRUNTEUR' LIMIT 1)
        AND age = 34
        AND duree_contrat = 60
        AND categorie = 'amortissable'
      LIMIT 1
    `);
    
    if (result3.rows.length > 0) {
      const prime = result3.rows[0].prime;
      const decimals = prime.includes('.') ? prime.split('.')[1].length : 0;
      
      console.log(`\n  Prime récupérée: ${prime}`);
      console.log(`  Nombre de décimales: ${decimals}`);
      
      if (decimals >= 5) {
        console.log('  ✅ SUCCÈS: La précision de 5 décimales est préservée !');
      } else {
        console.log('  ⚠️  ATTENTION: Moins de 5 décimales détectées');
      }
      
      // Simulation de calcul
      const montantPret = 10000000; // 10M FCFA
      const primeCalculee = (montantPret * parseFloat(prime)) / 100;
      console.log(`\n  💰 Simulation: Prêt de ${montantPret.toLocaleString()} FCFA`);
      console.log(`     Prime = ${primeCalculee.toFixed(2)} FCFA`);
    } else {
      console.log('  ⚠️  Aucun tarif trouvé pour cette combinaison');
    }
    
    // Conclusion
    console.log('\n═══════════════════════════════════════════════════════════');
    console.log('✅ Le système est prêt à gérer les 5 décimales pour FLEX');
    console.log('✅ L\'API avec cast ::TEXT préserve toute la précision');
    console.log('✅ Le modèle Dart parse correctement les strings');
    console.log('═══════════════════════════════════════════════════════════\n');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Erreur:', error);
    process.exit(1);
  }
}

testFlexPrecision();
