const express = require('express');
const router = express.Router();
const { verifyToken } = require('../middlewares/authMiddleware');
const upload = require('../config/multer');


const {
  createSubscription,
  updateSubscription,
  updateSubscriptionStatus,
  updatePaymentStatus,
  uploadDocument,
  getUserPropositions,   
  getUserContracts,
  getSubscriptionWithUserDetails,
  getSubscriptionPDF,
  attachProposal,
  getDocument
} = require('../controllers/subscriptionController');

// Routes
router.post('/create', verifyToken, createSubscription);
router.put('/:id/update', verifyToken, updateSubscription);
router.put('/:id/status', verifyToken, updateSubscriptionStatus);
router.put('/:id/payment-status', verifyToken, updatePaymentStatus);
router.post('/:id/upload-document', verifyToken, upload.single('document'), uploadDocument);
router.get('/user/propositions', verifyToken, getUserPropositions);
router.get('/user/contrats', verifyToken, getUserContracts);
// Routes spécifiques AVANT les routes génériques
router.get('/:id/pdf', verifyToken, getSubscriptionPDF);
router.get('/:id/document/:filename', verifyToken, getDocument);
// Route générique /:id EN DERNIER
router.get('/:id', verifyToken, getSubscriptionWithUserDetails);
router.post('/attach', verifyToken, attachProposal);
module.exports = router;